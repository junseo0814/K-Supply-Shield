# Handoff: K-Supply Shield 대시보드 (핵심광물 공급망 충격 시뮬레이터)

## Overview
산업통상부용 정부 대시보드. 로그인 화면(1) → 메인 시뮬레이터 대시보드(2)로 구성된 2화면 흐름이다.
대시보드에서는 광물 종류·공급 제한 비율·연간 수입 규모를 입력하면 직접 수입 충격, 총 생산 파급 손실,
고용 위협, 공급망 도미노 전파, 산업별 파급 손실, KOMIS 지수를 실시간으로 시뮬레이션해 보여준다.

## About the Design Files
이 번들의 HTML 파일은 **디자인 레퍼런스**입니다 — 최종 화면의 룩앤필과 동작을 보여주는 프로토타입이며,
그대로 복사해서 쓰는 프로덕션 코드가 아닙니다. 실제 구현 시에는 타깃 코드베이스에 이미 있는 프레임워크/
패턴(React, Vue 등)으로 이 디자인을 다시 만들어야 합니다. 아직 프론트엔드 환경이 없다면, 프로젝트에
가장 적합한 프레임워크를 선택해 구현하면 됩니다.

## Fidelity
**High-fidelity.** 색상, 타이포그래피, 간격, 그림자, 인터랙션이 모두 최종안 기준입니다. 픽셀 단위로
동일하게 재현하는 것을 목표로 하되, 아래 명시된 코드베이스의 기존 컴포넌트/토큰이 있다면 그것을
우선 사용하세요.

## Files
- `KSupplyShield.dc.html` — 다크 테마 버전
- `KSupplyShield-Light.dc.html` — **화이트 테마 (현재 채택된 메인 버전, 로그인 화면 포함)**
- `assets/motie-logo-horizontal.png` — 산업통상부 로고 (엠블럼 + 워드마크, 가로형 — 대시보드 사이드바 헤더용)
- `assets/motie-logo-stacked.png` — 산업통상부 로고 (엠블럼 + 워드마크, 세로형 — 로그인 화면용)

두 파일은 색상 토큰만 다르고 레이아웃/로직은 동일합니다. 화이트 테마가 최종 채택안이므로
`KSupplyShield-Light.dc.html`을 기준으로 구현하세요. (다크 버전에는 로그인 화면/상단 정보바가 없습니다.)

## Screens / Views

### 0. 로그인 화면 (최초 진입 화면)
전체 화면 중앙 정렬 카드(width 380px, 배경 #fff, radius 12px, 그림자 `0 20px 50px rgba(30,40,60,.16)`).
세로형 로고(엠블럼+"산업통상부" 텍스트, height 100px) + "K-Supply Shield" 타이틀(20px/800) +
부제 "핵심광물 공급망 충격 시뮬레이터 관리자 로그인" + 아이디/비밀번호 입력 + 로그인 버튼
(배경 #246beb, hover #1d57c2) + 하단 안내문구(11px, #9aa2ae). 로그인 버튼 클릭 시 대시보드(화면 1)로 전환.

### 1. 대시보드 (로그인 후 진입)
사이드바 + 메인 콘텐츠 레이아웃이며 스크롤로 아래 섹션들이 이어집니다. 메인 콘텐츠 최상단에
**우측 정렬 정보바**가 추가됨: 실시간 시계(1초 간격 갱신, `toLocaleString('ko-KR')`) · 구분선 ·
사용자명 "홍길동 사무관(자원공급망관리과)" · 로그아웃 버튼(클릭 시 로그인 화면으로 복귀).

### 2. 좌측 사이드바 (고정, width 300px, 배경 #ffffff, 우측 보더 1px rgba(10,20,35,0.08))
- **로고 영역**: 로고 이미지(height 34px) + 오른쪽에 "K-Supply Shield"(17px/800) / "핵심광물 공급망 충격 시뮬레이터"(12px/500, color #5b6472), flex-row, gap 12px
- **광물 선택**: label "광물 선택"(13px/700, #5b6472) + **커스텀 드롭다운** (네이티브 `<select>` 아님 — 버튼 클릭 시 절대 위치 리스트가 열리는 커스텀 컴포넌트). 7개 옵션: 흑연/리튬/코발트/니켈/망간/희토류/텅스텐. 버튼 배경 #fff, 보더는 현재 광물의 accent 색(45% 투명도 mix), radius 8px, 커스텀 shevron(CSS border 트릭, 우측 15px). 옵션 클릭 시 전체 화면 accent 컬러/수치가 즉시 바뀌고 드롭다운이 닫힘. (네이티브 select는 브라우저별 표시 라벨 리페인트 이슈가 있어 커스텀 드롭다운으로 구현했습니다 — 실제 구현 시 프레임워크의 정석적인 select/combobox 컴포넌트를 써도 무방합니다.)
- **공급 제한 비율 슬라이더**: label + 우측에 현재 값 "{pct}%"(20px/800, accent색). `<input type=range min=10 max=100>`, accent-color = 현재 accent.
- **한국 연간 수입 규모 입력**: `<input type=number step=0.01>`, 조원 단위. 광물 변경 시 해당 광물의 기본 수입 규모로 리셋됨.
- **예상 직접 충격 미리보기 카드**: 좌측 accent 보더 3px, 배경 #f7f8fa. "{importVolume}조원 × 제한 {pct}%" 산식 표시.

### 2. 상단 경보 배너
- 좌측 pulse 애니메이션 dot(1.8s 주기) + risk 배지("LOW"/"MEDIUM"/"HIGH", 배경 rgba 톤, 텍스트 risk색) + 메시지 문장 + 우측 기준일.
- pct ≤30 → LOW(success #228738), 30<pct≤60 → MEDIUM(warning #ffb015), pct>60 → HIGH(danger #de3411). 배경/보더도 각 색의 저채도 tint.

### 3. 핵심 지표 카드 4개 (grid 4열, minmax(0,1fr), gap 16px)
각 카드: 배경 #fff, 보더 1px rgba(10,20,35,0.08), 상단 3px 보더(카드별 강조색), radius 10px, padding 20px,
box-shadow `0 6px 18px rgba(30,40,60,.10), 0 1px 3px rgba(30,40,60,.08)`, hover 시 `translateY(-3px)` + 진한 그림자.
1. 직접 수입 충격 — accent색, `{importVolume × pct%} 조원`
2. 총 생산 파급 손실 — #ff8a3d, `직접충격 × multiplier`
3. 총 고용 위협 — #f0563a, `총손실 × empFactor` 명
4. 생산유발 배수 — #4f8bff, `{multiplier}배`
(숫자 줄바꿈 방지를 위해 white-space:nowrap 필수)

### 4. 공급망 도미노 충격 전파 (5단계 타임라인)
5개 박스를 →로 연결 (flex row, wrap). 각 박스: STEP n / 제목 / 설명. `activeStageCount = ceil(pct/20)` (1~5)만큼
왼쪽부터 활성화 — 활성 박스는 accent색 보더/텍스트/그림자, 비활성은 회색 톤.
단계: 공급차단 → 원자재재고소진 → 소재부품생산중단 → 완성품출하차질 → 수출손실현실화.

### 5. D+7 / D+18 / D+40 상세 카드 3개 (grid 3열)
각 카드: 상단에 accent 배경의 day 배지(흰 글씨) + phase 라벨, 그 아래 생산손실(#ff8a3d)/고용위협(#f0563a) 수치.
비율: D+7=15%, D+18=45%, D+40=100% (총손실/총고용 대비).

### 6. 산업별 생산 파급 손실 (가로 막대차트, 30개 섹터)
`grid-template-columns: 150px 1fr 90px` 행 반복, 막대는 accent색, 값 내림차순 정렬, 스크롤 컨테이너(max-height 560px).

### 7. KOMIS 광물종합지수
좌측 SVG 라인차트(12개월, accent색 stroke) + 우측 통계 3개(희소금속지수 +120%대, 종합원자재지수, {광물}관련지수 — 좌측 accent 보더).

## Interactions & Behavior
- 광물 변경 → accent 컬러 전체 갱신, 수입규모 필드가 해당 광물 기본값으로 리셋, 모든 수치 재계산.
- 슬라이더/입력값 변경 → 즉시 재계산 (디바운스 없음).
- 카드 hover → translateY(-2~3px) + 그림자 강화.
- `<select>`는 네이티브 select이며 각 `<option>`에 `selected` 속성을 명시하고, 광물이 바뀔 때마다 select를
  **key로 리마운트**해야 브라우저가 표시 라벨을 정확히 갱신함 (React 컨트롤드 select value prop만으로는
  일부 렌더 경로에서 라벨이 갱신되지 않는 이슈가 있었음 — 실제 구현 시 React라면 `value`+`onChange`로
  정상 컨트롤드 컴포넌트로 구현하면 됨).

## State Management
```
mineral: string (기본 '리튬')
pct: number 10~100 (기본 40)
importVolume: number 조원 (기본 0.825, 광물 변경 시 해당 광물 baseImport로 리셋)
```
파생값(모두 mineral+pct+importVolume에서 계산): directImpact, totalLoss, employment, riskLevel,
activeStageCount, stageDetails[3], industries[30](정렬됨), komisPoints, komisStats[3].

## Design Tokens

### Colors (화이트 테마)
- 배경: #f4f5f7 / 사이드바·카드: #ffffff
- 텍스트 주: #1e2225, 보조: #5b6472, 3차: #8a93a0
- 보더: rgba(10,20,35,0.08~0.14)
- Primary(정부 청색): #246beb, 다크 네이비: #0c3388
- Danger: #de3411 / Warning: #ffb015 / Success: #228738
- 지표카드 강조: 총손실 #ff8a3d, 고용 #f0563a, 배수 #4f8bff

### 광물별 Accent (oklch)
| 광물 | accent | baseImport(조원) | multiplier | empFactor |
|---|---|---|---|---|
| 흑연 | oklch(72% 0.02 250) | 1.05 | 1.8 | 2600 |
| 리튬 | oklch(65% 0.19 300) | 0.825 | 2.1 | 3098.13 |
| 코발트 | oklch(68% 0.14 220) | 0.68 | 2.4 | 3400 |
| 니켈 | oklch(70% 0.15 165) | 1.30 | 1.9 | 2200 |
| 망간 | oklch(68% 0.17 340) | 0.45 | 1.6 | 1900 |
| 희토류 | oklch(75% 0.14 85) | 1.65 | 2.6 | 3800 |
| 텅스텐 | oklch(65% 0.17 260) | 0.38 | 2.0 | 2500 |

### Typography
Pretendard (jsdelivr CDN: `pretendard@v1.3.9`), 본문 최소 16px 지향(카드 라벨류는 예외적으로 12~13px 사용),
line-height 150%.

### Spacing / Radius
8pt 그리드 기준 (12/16/20/24/28/36px 등), 카드 radius 10px, 인풋/셀렉트 radius 8px.

### Shadows
카드: `0 6px 18px rgba(30,40,60,.10), 0 1px 3px rgba(30,40,60,.08)` / hover: `0 14px 30px rgba(30,40,60,.16)`.

## Assets
- `assets/motie-logo-horizontal.png` — 사용자가 업로드한 산업통상부 공식 로고(엠블럼+워드마크). 실제 구현 시
  기관에서 제공하는 최신 로고 원본(벡터, SVG/AI) 사용을 권장.

## State Management (로그인 화면 포함 갱신)
```
loggedIn: boolean (기본 false) — true가 되면 대시보드 표시, false면 로그인 화면 표시
loginId, loginPw: string (더미, 실제 인증 로직 없음)
dropdownOpen: boolean — 광물 커스텀 드롭다운 열림 여부
now: timestamp, 1초마다 setInterval로 갱신 → 상단 정보바 시계
mineral, pct, importVolume: 기존과 동일
```

## Note on dark theme
`KSupplyShield.dc.html`(다크)도 함께 포함되어 있으나 현재 채택안은 화이트 테마입니다. 다크 테마가
필요할 경우를 대비해 색 토큰만 참고용으로 남겨둡니다.
